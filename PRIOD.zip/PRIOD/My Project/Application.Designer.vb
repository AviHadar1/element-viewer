Namespace My
    'This class allows you to handle specific events on the application level
    Partial Friend Class MyApplication
    End Class
End Namespace
