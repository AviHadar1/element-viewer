﻿Imports System.Data
Imports System.Drawing
Imports System.IO
Imports System.Net.NetworkInformation
Imports System.Text.RegularExpressions
Imports System.Windows.Forms

Public Class Form1
    ' Declare at class level
    Private WithEvents panelTop As New Panel
    Private WithEvents btnLoad As New Button
    Private WithEvents btnGenerate As New Button
    Private WithEvents btnUpdate As New Button
    Private WithEvents gridPeriodic As New DataGridView
    Private WithEvents grid As New DataGridView

    Public Class StructureResult
        Public Property FileName As String
        Public Property RingsNumber As Integer
        Public Property RingNeutrons As Integer
        Public Property AxisProtons As Integer
        Public Property AxisNeutrons As Integer
        Public Property CameraDistance As Integer
    End Class

    Private Class ElementStructure
        Public FileName As String
        Public RingsNumber As Integer
        Public RingNeutrons As Integer
        Public AxisNeutrons As Integer
        Public AxisProtons As Integer
        Public CameraDistance As Integer = 50
        Public RingTiltAngle As Double = 0
        Public Title As String = ""
        Public AxisFormula As String
    End Class

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "Ball Array Generator"
        Me.Size = New Size(800, 700)
        Me.WindowState = FormWindowState.Maximized

        ' Top panel
        panelTop.Dock = DockStyle.Top
        panelTop.Height = 40
        panelTop.BackColor = Color.White
        Me.Controls.Add(panelTop)

        ' Load button
        btnLoad.Text = "Load"
        btnLoad.Size = New Size(120, 30)
        btnLoad.Location = New Point(10, 3)
        panelTop.Controls.Add(btnLoad)

        ' Generate button
        btnGenerate.Text = "Generate"
        btnGenerate.Size = New Size(120, 30)
        btnGenerate.Location = New Point(140, 3)
        panelTop.Controls.Add(btnGenerate)

        ' Update List button
        btnUpdate.Text = "Update List"
        btnUpdate.Size = New Size(120, 30)
        btnUpdate.Location = New Point(270, 3)
        AddHandler btnUpdate.Click, AddressOf btnUpdateList_Click
        panelTop.Controls.Add(btnUpdate)

        ' Grid for periodic table
        gridPeriodic.Dock = DockStyle.Top
        gridPeriodic.Height = 400
        'gridPeriodic.ReadOnly = True
        gridPeriodic.AllowUserToAddRows = False
        gridPeriodic.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
        Me.Controls.Add(gridPeriodic)

        ' Grid for configuration
        grid.Dock = DockStyle.Fill
        grid.AllowUserToAddRows = False
        grid.Columns.Clear()
        grid.Columns.Add("FileName", "FileName")
        grid.Columns.Add("AxisFormula", "AxisFormula")            ' ← במקום AxisProtons/Neutrons
        grid.Columns.Add("CameraDistance", "CameraDistance")
        grid.Columns.Add("RingTiltAngle", "RingTiltAngle")        ' ← חדש: זווית הטיה
        grid.Columns.Add("Title", "Title")
        grid.Columns.Add("RingsNumber", "RingsNumber")
        grid.Columns.Add("P_ring", "P_ring")
        grid.Columns.Add("P_axis", "P_axis")
        grid.Columns.Add("AxisLen", "AxisLen")
        grid.Columns.Add("CalcBindingEnergy", "CalcBindingEnergy")
        grid.Columns.Add("BindingEnergy", "BindingEnergy")
        grid.Columns.Add("BindingEnergyRatio", "BindingEnergyRatio")

        Me.Controls.Add(grid)

        gridPeriodic.SendToBack()
        panelTop.SendToBack()

        ' Load periodic table from embedded resource
        LoadPeriodicTable()
        'gridPeriodic.DataSource = periodicTable
    End Sub
    Dim baseDir As String = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\..\.."))
    Dim resourceDir As String = Path.Combine(baseDir, "Resources")
    'Dim csvPath As String = Path.Combine(resourceDir, "PeriodicTable_Isotopes-U-235-1.csv")
    Dim csvPath As String = Path.Combine(resourceDir, "PeriodicTable_Isotopes.csv")
    'Dim csvPath As String = Path.Combine(resourceDir, "PeriodicTable_Isotopes full.csv")

    Private Sub LoadPeriodicTable()
        Try

            If Not File.Exists(csvPath) Then
                MessageBox.Show("File not found: " & csvPath)
                Return
            End If

            Dim table As New DataTable()
            Dim lines = File.ReadAllLines(csvPath)

            If lines.Length = 0 Then Exit Sub

            ' Create columns
            Dim headers = lines(0).Split(","c)
            For Each header In headers
                table.Columns.Add(header.Trim())
            Next

            ' Add rows
            For i As Integer = 1 To lines.Length - 1
                Dim values = lines(i).Split(","c)
                table.Rows.Add(values)
            Next

            gridPeriodic.DataSource = table

        Catch ex As Exception
            MessageBox.Show("Error loading periodic table: " & ex.Message)
        End Try
    End Sub

    Private Sub btnUpdateList_Click(sender As Object, e As EventArgs)
        grid.Rows.Clear()

        For Each row As DataGridViewRow In gridPeriodic.Rows
            Dim P_Number As Integer = Convert.ToInt32(row.Cells("AtomicNumber").Value)
            Dim N_Number As Integer = Convert.ToInt32(row.Cells("NeutronsNumber").Value)
            Dim BindingEnergy As Double = Convert.ToDouble(row.Cells("BindingEnergy").Value)
            Dim Name As String = row.Cells("Name").Value.ToString()
            Dim Period As Integer = Convert.ToInt32(row.Cells("Period").Value)
            Dim RingsNum = Period
            Dim formulas As List(Of String) = BuildFormula(P_Number, N_Number, Name, RingsNum)
            Dim N_AxisLen As Integer = 0
            Dim CamFactor As Integer = 3
            'If formulas.Count > 0 Then
            '    Dim i As Integer = 0
            '    Do
            '        If GetMaxNSequence(formulas(i), N_AxisLen) > 3 Then
            '            formulas.Remove(formulas(i))
            '        Else
            '            i += 1
            '        End If
            '        If i >= formulas.Count Then
            '            Exit Do
            '        End If
            '    Loop
            'End If
            'If formulas.Count = 1 Then
            '    Dim AxLen As Integer = IIf(AxisLen < 10, 10, AxisLen)
            '    AxLen = AxLen * CamFactor
            '    grid.Rows.Add(
            '                    Name,
            '                    formulas(0),
            '                    AxLen,  ' CameraDistance
            '                    "",  ' RingTiltAngle
            '                    P_Number   ' Title
            '                    )
            If formulas.Count > 0 Then
                Dim FormulaIndex As Integer = 1
                For Each formula As String In formulas
                    Dim RingsNumber As Integer = 0
                    Dim P_ring As Integer = 0
                    Dim P_axis As Integer = 0
                    Dim AxisLen As Integer = 0
                    Dim CalcBindingEnergy As Double = 0
                    Dim BindingEnergyRatio As Double = 0
                    Dim NewNane As String = Name
                    If formulas.Count > 1 Then
                        NewNane &= "_" & FormulaIndex
                        FormulaIndex += 1
                    End If
                    Call ParseAxisRingFormula(formula, RingsNumber, P_ring, P_axis, AxisLen)
                    'CalcBindingEnergy = CalculateBindingEnergy(P_Number + N_Number, P_ring, RingsNumber, P_axis, AxisLen)
                    'BindingEnergyRatio = (BindingEnergy - CalcBindingEnergy) / BindingEnergy * 100.0
                    Dim AxisLen1 As Integer = IIf(AxisLen < 10, 10, AxisLen)
                    Dim CameraDistance As Integer = AxisLen1 * CamFactor

                    grid.Rows.Add(
                    NewNane,
                    formula,
                    CameraDistance,  ' CameraDistance
                    "",  ' RingTiltAngle
                    P_Number,   ' Title
                    RingsNumber,
                    P_ring,
                    P_axis,
                    AxisLen,
                    CalcBindingEnergy,
                    BindingEnergy,
                    BindingEnergyRatio
                )
                Next
            End If
        Next
    End Sub

    Public Function BuildFormula(P_Number As Integer, N_Number As Integer, Name As String, RingsNumber As Integer) As List(Of String)
        Dim formula As New List(Of String)

        Select Case RingsNumber
            Case 0
                formula.Add("PNNP")

            Case 1
                Dim ringP As Integer = P_Number - 2
                Dim ringN As Integer = N_Number - 2
                formula.Add($"PN[R{ringP}N{ringN}E0]N[R0N0E0]P")

            Case 2
                Dim outerLeftP As Integer = 8
                Dim outerLeftN As Integer = 8
                Dim outerRightP As Integer = P_Number - 2 - outerLeftP
                Dim outerRightN As Integer = N_Number - 2 - outerLeftN
                formula.Add($"PN[R{outerLeftP}N{outerLeftN}E0]N[R{outerRightP}N{outerRightN}E0]P")

            Case 4
                formula.Add(BuildFourRingSegment(P_Number, N_Number))

            Case Else
                formula.Add("Unsupported number of rings")
        End Select

        Return formula
    End Function

    Private Function BuildFourRingSegment(P_Number As Integer, N_Number As Integer) As String
        Dim P(5) As Integer
        Dim N(5) As Integer
        P_Number = P_Number - 4
        N_Number = N_Number - 6
        Dim P_Left As Integer = P_Number
        Dim N_Left As Integer = N_Number

        For i As Integer = 0 To 2
            If P_Left > 16 Then
                P(i) = 8
                P(5 - i) = 8
                P_Left -= 16
            ElseIf P_Left > 0 Then
                P(i) = (P_Left + 1) \ 2
                P(5 - i) = P_Left - P(i)
                P_Left = 0
                Select Case P(i)
                    Case 1, 2, 3, 7
                        If N_Left > P(i) Then
                            N(i) = P(i) + 1
                        End If
                        N_Left -= N(i)
                    Case Else
                        If N_Left > 0 Then
                            N(i) = P(i)
                        End If
                        N_Left -= N(i)
                End Select
                Select Case P(5 - i)
                    Case 1, 2, 3, 7
                        If N_Left > P(5 - i) Then
                            N(5 - i) = P(5 - i) + 1
                        End If
                        N_Left -= N(5 - i)
                    Case Else
                        If N_Left > 0 Then
                            N(5 - i) = P(5 - i)
                        End If
                        N_Left -= N(5 - i)
                End Select
            ElseIf N_Left > 0 Then
                N(i) = (N_Left + 1) \ 2
                N(5 - i) = N_Left - N(i)
                N_Left = 0
            End If
            If N_Left > 16 Then
                N(i) = 8
                N(5 - i) = 8
                N_Left -= 16
            End If
        Next
        Return $"PN[R{P(0)}N{N(0)}E0]N[R{P(1)}N{N(1)}E0]PN[R{P(2)}N{N(2)}E0]N[R{P(3)}N{N(3)}E0]PN[R{P(4)}N{N(4)}E0]N[R{P(5)}N{N(5)}E0]P"
    End Function

    Private Function InsertRingsIntoFormula(finalFormula As String, RingsNumber As Integer, N_LastRing As Integer, P_LastRing As Integer) As String
        Dim Ring As String = "[R8N8E0]"
        If RingsNumber = 0 Then Return finalFormula

        ' חלוקה לרשימה של בלוקים (P, NN, NNN וכו') לפי הופעות של P
        Dim parts As New List(Of String)
        Dim buffer As String = ""
        Dim RemainRings As Integer = RingsNumber
        Dim i As Integer = 0

        buffer = ""
        For Each ch In finalFormula
            If ch = "P"c Then
                If buffer <> "" Then parts.Add(buffer)
                parts.Add("P")
                buffer = ""
            Else
                buffer &= ch
            End If
        Next
        If buffer <> "" Then parts.Add(buffer)
        i = 1
        Do While RemainRings > 0
            If RemainRings = 1 Then
                Ring = "[R" & P_LastRing & "N" & N_LastRing & "E0]"
                Select Case parts(1)
                    Case "NN" : parts(1) = "N" & Ring & "N"
                    Case "NNN" : parts(1) = "NN" & Ring & "N"
                    Case "NNNN" : parts(1) = "NN" & Ring & "NN"
                    Case Else : parts(0) &= Ring

                End Select
                Exit Do
            ElseIf RemainRings > 2 Then
                parts(i) &= Ring
                RemainRings -= 1
            End If

            If RemainRings = 0 Then
                Exit Do
            End If

            If RemainRings > 1 Then
                parts(parts.Count - i) = Ring & parts(parts.Count - i)
                RemainRings -= 1
            End If
            If RemainRings = 0 Then
                Exit Do
            End If
        Loop
        Return String.Join("", parts)
    End Function

    Private Function LockForPNNP(finalFormula) As Integer
        Dim i As Integer = 0
        Dim parts As New List(Of String)
        Dim buffer As String = ""
        buffer = ""
        For Each ch In finalFormula
            If ch = "P"c Then
                If buffer <> "" Then parts.Add(buffer)
                parts.Add("P")
                buffer = ""
            Else
                buffer &= ch
            End If
        Next
        If buffer <> "" Then parts.Add(buffer)
        i = parts.Count - 3
        Do While i >= 0
            If parts(i) = "P" AndAlso parts(i + 1) = "NN" AndAlso parts(i + 2) = "P" Then
                LockForPNNP += 1
            End If
            i -= 1
        Loop
    End Function


    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        Dim openFileDialog As New OpenFileDialog()
        openFileDialog.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*"

        If openFileDialog.ShowDialog() = DialogResult.OK Then
            Try
                Dim lines = File.ReadAllLines(openFileDialog.FileName)

                If lines.Length < 2 Then
                    MessageBox.Show("No data To load.")
                    Return
                End If

                ' Clear existing rows
                grid.Rows.Clear()

                ' Start from second line (skip header)
                For i As Integer = 1 To lines.Length - 1
                    Dim fields = lines(i).Split(","c)

                    ' מצפים ל-12 עמודות בדיוק
                    If fields.Length = 12 Then
                        grid.Rows.Add(fields)
                    Else
                        MessageBox.Show("Invalid row format (expecting 12 fields): " & lines(i))
                    End If
                Next

            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End If
    End Sub


    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        Dim baseDir As String = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\..\.."))
        Dim outputDir As String = Path.Combine(baseDir, "Output")
        Dim templatePath = Path.Combine(baseDir, "Resources\main.template.js")
        Dim htmlTemplatePath = Path.Combine(baseDir, "Resources\index.template.html")

        If Not File.Exists(templatePath) Then
            MessageBox.Show("main.template.js not found!")
            Return
        End If

        If Not File.Exists(htmlTemplatePath) Then
            MessageBox.Show("index.template.html not found!")
            Return
        End If

        Directory.CreateDirectory(outputDir)

        For Each row As DataGridViewRow In grid.Rows
            If row.IsNewRow Then Continue For

            Dim fileName = row.Cells("FileName").Value?.ToString()
            Dim axisFormula = row.Cells("AxisFormula").Value?.ToString()
            Dim cameraDistance = row.Cells("CameraDistance").Value?.ToString()
            Dim ringTiltAngle = row.Cells("RingTiltAngle").Value?.ToString()
            Dim title = row.Cells("Title").Value?.ToString()
            'Dim RingsNumber = row.Cells("RingsNumber").Value?.ToString()
            'Dim P_ring = row.Cells("P_ring").Value?.ToString()
            'Dim P_axis = row.Cells("P_axis").Value?.ToString()
            'Dim AxisLen = row.Cells("AxisLen").Value?.ToString()
            'Dim CalcBindingEnergy = row.Cells("CalcBindingEnergy").Value?.ToString()
            'Dim BindingEnergy = row.Cells("BindingEnergy").Value?.ToString()
            'Dim BindingEnergyRatio = row.Cells("BindingEnergyRatio").Value?.ToString()

            If String.IsNullOrWhiteSpace(fileName) OrElse String.IsNullOrWhiteSpace(axisFormula) Then Continue For

            ' Fallback values
            If String.IsNullOrWhiteSpace(cameraDistance) Then cameraDistance = "50"
            If String.IsNullOrWhiteSpace(ringTiltAngle) Then ringTiltAngle = "0"
            'If String.IsNullOrWhiteSpace(title) Then title = fileName

            ' Load JS template and replace tokens
            Dim jsCode = File.ReadAllText(templatePath)
            jsCode = jsCode.Replace("$AxisFormula$", axisFormula)
            jsCode = jsCode.Replace("$CameraDistance$", cameraDistance)
            jsCode = jsCode.Replace("$RingTiltAngle$", ringTiltAngle)
            jsCode = jsCode.Replace("$Title$", fileName & " " & title)

            ' Load HTML template and replace title
            Dim htmlCode = File.ReadAllText(htmlTemplatePath)
            htmlCode = htmlCode.Replace("$Title$", title)

            ' Write output files
            Dim folderPath = Path.Combine(outputDir, fileName)
            Directory.CreateDirectory(folderPath)

            File.WriteAllText(Path.Combine(folderPath, "main.js"), jsCode)
            File.WriteAllText(Path.Combine(folderPath, "index.html"), htmlCode)
        Next

        'MessageBox.Show("Generation complete!")
    End Sub
    ''' <summary>
    ''' מחשב את אנרגיית הקשר הכוללת לפי מודל Axis–Ring עבור גרעין אטומי.
    ''' בהנחה שכל הטבעות זהות בגודל (מספר פרוטונים אחיד).
    ''' </summary>
    ''' <param name="A">סה"כ נוקלאונים בגרעין (פרוטונים + נויטרונים)</param>
    ''' <param name="P_ring">מספר הפרוטונים בכל טבעת</param>
    ''' <param name="R">מספר טבעות</param>
    ''' <param name="P_axis">מספר הפרוטונים בציר המרכזי</param>
    ''' <param name="L">אורך הציר (ביחידות של נוקלאונים)</param>
    ''' <returns>אנרגיית הקשר הכוללת [MeV]</returns>
    Public Function CalculateBindingEnergy(A As Integer, P_ring As Integer, R As Integer, P_axis As Integer, L As Integer) As Double
        ' 1. Base energy
        Dim E_base As Double = A * 7.08

        ' 2. Ring energy – בחירת נוסחה לפי מספר הטבעות
        Dim E_max As Double = 40
        Dim k As Double = 0.11
        Dim E_ring_single As Double

        If R = 1 Then
            ' נוסחה פרבולית לטבעת בודדת
            E_ring_single = -0.012 * (P_ring ^ 2) + 0.841 * P_ring - 0.508
        Else
            ' נוסחה מעריכית למספר טבעות
            E_ring_single = E_max * (1 - Math.Exp(-k * P_ring))
        End If

        Dim E_ring As Double = R * E_ring_single

        ' 3. Axis energy – תלוי ביחס בין טבעות לאורך הציר
        Dim ratio As Double = R / L
        Dim E_axis As Double = P_axis * (-0.56 + 46.38 * ratio - 100.72 * ratio * ratio)

        ' Total energy
        Return E_base + E_ring + E_axis
    End Function

    Public Sub ParseAxisRingFormula(formula As String, ByRef RingsNumber As Integer, ByRef P_ring As Integer, ByRef P_axis As Integer, ByRef AxisLen As Integer)
        ' שלב 1: מצא את כל הטבעות
        Dim rings = System.Text.RegularExpressions.Regex.Matches(formula, "R(\d+)E\d+")
        RingsNumber = rings.Count

        ' נניח שכל הטבעות זהות — ניקח את הערך מהראשונה (אם קיימת)
        If RingsNumber > 0 Then
            P_ring = Convert.ToInt32(rings(0).Groups(1).Value)
        Else
            P_ring = 0
        End If

        ' שלב 2: הסר את כל הטבעות כדי להשאיר רק את הציר
        Dim axisOnly = System.Text.RegularExpressions.Regex.Replace(formula, "\[.*?\]", "")

        ' שלב 3: ספר כמה תווי P יש בציר
        P_axis = axisOnly.Count(Function(c) c = "P"c)

        ' שלב 4: אורך הציר = מספר התווים הכולל שנותרו
        AxisLen = axisOnly.Length
    End Sub

End Class
